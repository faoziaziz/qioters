```bash
curl -X 'POST' \
  'http://localhost:8000/itemszab?item_id=udah' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "name": "test.key"
}'

```