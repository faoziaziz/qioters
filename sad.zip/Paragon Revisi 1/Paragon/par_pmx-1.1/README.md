# par_pmx

berisi design hardware dan gateway untuk akses ke zabbix


hardware ada dalam direktory ***pg_hw*** gateway ada dalam direktory ***gateway***
